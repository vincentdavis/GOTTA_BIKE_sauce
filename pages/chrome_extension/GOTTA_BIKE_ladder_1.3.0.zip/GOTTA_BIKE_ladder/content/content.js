/**
 * Content script for GOTTA.BIKE ladder
 * Extracts team data from ladder.cycleracing.club pages
 */

function extractTeamData() {
  const teamSection = document.querySelector('#teamId');

  if (!teamSection) {
    return {
      error: true,
      message: 'No team data found on this page. Make sure you are on a team page.'
    };
  }

  // Extract team name
  const teamNameEl = teamSection.querySelector('.h1');
  const teamName = teamNameEl ? teamNameEl.textContent.trim() : null;

  // Extract club name from the newpill span
  const clubPillEl = teamSection.querySelector('.newpill');
  let clubName = null;
  if (clubPillEl && clubPillEl.textContent) {
    clubName = clubPillEl.textContent.trim();
  }

  // Extract captain (text starts with "Captain")
  const captainEl = teamSection.querySelector('.fw-bold');
  let captain = null;
  if (captainEl) {
    const captainText = captainEl.textContent.trim();
    if (captainText.startsWith('Captain ')) {
      captain = captainText.replace('Captain ', '');
    } else {
      captain = captainText;
    }
  }

  // Extract vice captains
  const viceCaptainsEl = teamSection.querySelector('.h6.text-muted');
  let viceCaptains = [];
  if (viceCaptainsEl) {
    const vcText = viceCaptainsEl.textContent.trim();
    if (vcText.startsWith('Vice captains ')) {
      const vcNames = vcText.replace('Vice captains ', '');
      viceCaptains = vcNames.split(', ').map(name => name.trim());
    } else if (vcText.startsWith('Vice captain ')) {
      viceCaptains = [vcText.replace('Vice captain ', '').trim()];
    }
  }

  // Extract division ranks
  const ranksContainer = teamSection.querySelector('.teamRanks');
  const ranks = [];
  if (ranksContainer) {
    const rankPills = ranksContainer.querySelectorAll('.rounded-pill');
    rankPills.forEach(pill => {
      const positionEl = pill.querySelector('.bg-warning, .bg-white');
      const divisionEl = pill.querySelector('span.ms-2');

      if (positionEl && divisionEl) {
        ranks.push({
          division: divisionEl.textContent.trim(),
          position: parseInt(positionEl.textContent.trim(), 10)
        });
      }
    });
  }

  // Extract riders from the power table
  const riders = extractRiders();

  return {
    error: false,
    timestamp: new Date().toISOString(),
    url: window.location.href,
    team: {
      name: teamName,
      club: clubName,
      captain: captain,
      viceCaptains: viceCaptains,
      ranks: ranks,
      riders: riders
    }
  };
}

/**
 * Extract rider data from the newPowerTable
 */
function extractRiders() {
  const riders = [];
  const powerTable = document.querySelector('.newPowerTable');

  if (!powerTable) {
    return riders;
  }

  const riderRows = powerTable.querySelectorAll('tr[data-rider-id]');

  riderRows.forEach(row => {
    const riderId = row.getAttribute('data-rider-id');

    // Find the cell with rider name (has data-goto attribute)
    const nameCell = row.querySelector('td[data-goto]');
    let riderName = null;
    let profilePath = null;

    if (nameCell) {
      profilePath = nameCell.getAttribute('data-goto');
      riderName = nameCell.textContent.trim();
    }

    if (riderId) {
      riders.push({
        rider_id: riderId,
        name: riderName,
        profile: profilePath
      });
    }
  });

  return riders;
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'extractData') {
    const data = extractTeamData();
    sendResponse(data);
  }
  return true;
});
